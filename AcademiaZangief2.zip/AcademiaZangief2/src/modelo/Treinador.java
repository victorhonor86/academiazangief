
package modelo;

import java.util.Objects;


public class Treinador {
   
    private String nomeTreinador;
    private String cpfTreinador;
    private String telefoneTreinador;
    private String emailTreinador;
    private String enderecoTreinador;
    private int codigo;

    public Treinador(String nomeTreinador, String cpfTreinador, String telefoneTreinador, String emailTreinador, String enderecoTreinador) {
        this.nomeTreinador = nomeTreinador;
        this.cpfTreinador = cpfTreinador;
        this.telefoneTreinador = telefoneTreinador;
        this.emailTreinador = emailTreinador;
        this.enderecoTreinador = enderecoTreinador;
    }

    public Treinador(String nomeTreinador, String cpfTreinador, String telefoneTreinador, String emailTreinador, String enderecoTreinador, int codigo) {
        this.nomeTreinador = nomeTreinador;
        this.cpfTreinador = cpfTreinador;
        this.telefoneTreinador = telefoneTreinador;
        this.emailTreinador = emailTreinador;
        this.enderecoTreinador = enderecoTreinador;
        this.codigo = codigo;
    }

    public Treinador() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getNomeTreinador() {
        return nomeTreinador;
    }

    public void setNomeTreinador(String nomeTreinador) {
        this.nomeTreinador = nomeTreinador;
    }

    public String getCpfTreinador() {
        return cpfTreinador;
    }

    public void setCpfTreinador(String cpfTreinador) {
        this.cpfTreinador = cpfTreinador;
    }

    public String getTelefoneTreinador() {
        return telefoneTreinador;
    }

    public void setTelefoneTreinador(String telefoneTreinador) {
        this.telefoneTreinador = telefoneTreinador;
    }

    public String getEmailTreinador() {
        return emailTreinador;
    }

    public void setEmailTreinador(String emailTreinador) {
        this.emailTreinador = emailTreinador;
    }

    public String getEnderecoTreinador() {
        return enderecoTreinador;
    }

    public void setEnderecoTreinador(String enderecoTreinador) {
        this.enderecoTreinador = enderecoTreinador;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.nomeTreinador);
        hash = 97 * hash + Objects.hashCode(this.cpfTreinador);
        hash = 97 * hash + Objects.hashCode(this.telefoneTreinador);
        hash = 97 * hash + Objects.hashCode(this.emailTreinador);
        hash = 97 * hash + Objects.hashCode(this.enderecoTreinador);
        hash = 97 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Treinador other = (Treinador) obj;
        return true;
    }

    @Override
    public String toString() {
        return "Treinador{" + "nomeTreinador=" + nomeTreinador + ", cpfTreinador=" + cpfTreinador + ", telefoneTreinador=" + telefoneTreinador + ", emailTreinador=" + emailTreinador + ", enderecoTreinador=" + enderecoTreinador + ", codigo=" + codigo + '}';
    }

}
