
package modelo;

import java.util.Objects;


public class Treino {
   
    private int codigoAluno;
    private int codigoTreinador;
    private String nomeTreino;
    private int numeroDeSeries;
    private int numeroDeRepeticoes;
    private int codigoExercicio;
    private int numeroDeSeries2;
    private int numeroDeRepeticoes2;
    private int codigoExercicio2;
    private int numeroDeSeries3;
    private int numeroDeRepeticoes3;
    private int codigoExercicio3;
    private int numeroDeSeries4;
    private int numeroDeRepeticoes4;
    private int codigoExercicio4;
    private int numeroDeSeries5;
    private int numeroDeRepeticoes5;
    private int codigoExercicio5;
    private int codigo;

    public Treino(int codigoAluno, int codigoTreinador, String nomeTreino, int codigo) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.nomeTreino = nomeTreino;
        this.codigo = codigo;
    }

    public Treino(int codigoAluno, int codigoTreinador, String nomeTreino, int numeroDeSeries, int numeroDeRepeticoes, int codigoExercicio, int numeroDeSeries2, int numeroDeRepeticoes2, int codigoExercicio2, int numeroDeSeries3, int numeroDeRepeticoes3, int codigoExercicio3, int numeroDeSeries4, int numeroDeRepeticoes4, int codigoExercicio4, int numeroDeSeries5, int numeroDeRepeticoes5, int codigoExercicio5) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.nomeTreino = nomeTreino;
        this.numeroDeSeries = numeroDeSeries;
        this.numeroDeRepeticoes = numeroDeRepeticoes;
        this.codigoExercicio = codigoExercicio;
        this.numeroDeSeries2 = numeroDeSeries2;
        this.numeroDeRepeticoes2 = numeroDeRepeticoes2;
        this.codigoExercicio2 = codigoExercicio2;
        this.numeroDeSeries3 = numeroDeSeries3;
        this.numeroDeRepeticoes3 = numeroDeRepeticoes3;
        this.codigoExercicio3 = codigoExercicio3;
        this.numeroDeSeries4 = numeroDeSeries4;
        this.numeroDeRepeticoes4 = numeroDeRepeticoes4;
        this.codigoExercicio4 = codigoExercicio4;
        this.numeroDeSeries5 = numeroDeSeries5;
        this.numeroDeRepeticoes5 = numeroDeRepeticoes5;
        this.codigoExercicio5 = codigoExercicio5;
    }

    public Treino(int codigoAluno, int codigoTreinador, String nomeTreino, int numeroDeSeries, int numeroDeRepeticoes, int codigoExercicio, int numeroDeSeries2, int numeroDeRepeticoes2, int codigoExercicio2, int numeroDeSeries3, int numeroDeRepeticoes3, int codigoExercicio3, int numeroDeSeries4, int numeroDeRepeticoes4, int codigoExercicio4, int numeroDeSeries5, int numeroDeRepeticoes5, int codigoExercicio5, int codigo) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.nomeTreino = nomeTreino;
        this.numeroDeSeries = numeroDeSeries;
        this.numeroDeRepeticoes = numeroDeRepeticoes;
        this.codigoExercicio = codigoExercicio;
        this.numeroDeSeries2 = numeroDeSeries2;
        this.numeroDeRepeticoes2 = numeroDeRepeticoes2;
        this.codigoExercicio2 = codigoExercicio2;
        this.numeroDeSeries3 = numeroDeSeries3;
        this.numeroDeRepeticoes3 = numeroDeRepeticoes3;
        this.codigoExercicio3 = codigoExercicio3;
        this.numeroDeSeries4 = numeroDeSeries4;
        this.numeroDeRepeticoes4 = numeroDeRepeticoes4;
        this.codigoExercicio4 = codigoExercicio4;
        this.numeroDeSeries5 = numeroDeSeries5;
        this.numeroDeRepeticoes5 = numeroDeRepeticoes5;
        this.codigoExercicio5 = codigoExercicio5;
        this.codigo = codigo;
    }

    public int getCodigoAluno() {
        return codigoAluno;
    }

    public void setCodigoAluno(int codigoAluno) {
        this.codigoAluno = codigoAluno;
    }

    public int getCodigoTreinador() {
        return codigoTreinador;
    }

    public void setCodigoTreinador(int codigoTreinador) {
        this.codigoTreinador = codigoTreinador;
    }

    public String getNomeTreino() {
        return nomeTreino;
    }

    public void setNomeTreino(String nomeTreino) {
        this.nomeTreino = nomeTreino;
    }

    public int getNumeroDeSeries() {
        return numeroDeSeries;
    }

    public void setNumeroDeSeries(int numeroDeSeries) {
        this.numeroDeSeries = numeroDeSeries;
    }

    public int getNumeroDeRepeticoes() {
        return numeroDeRepeticoes;
    }

    public void setNumeroDeRepeticoes(int numeroDeRepeticoes) {
        this.numeroDeRepeticoes = numeroDeRepeticoes;
    }

    public int getCodigoExercicio() {
        return codigoExercicio;
    }

    public void setCodigoExercicio(int codigoExercicio) {
        this.codigoExercicio = codigoExercicio;
    }

    public int getNumeroDeSeries2() {
        return numeroDeSeries2;
    }

    public void setNumeroDeSeries2(int numeroDeSeries2) {
        this.numeroDeSeries2 = numeroDeSeries2;
    }

    public int getNumeroDeRepeticoes2() {
        return numeroDeRepeticoes2;
    }

    public void setNumeroDeRepeticoes2(int numeroDeRepeticoes2) {
        this.numeroDeRepeticoes2 = numeroDeRepeticoes2;
    }

    public int getCodigoExercicio2() {
        return codigoExercicio2;
    }

    public void setCodigoExercicio2(int codigoExercicio2) {
        this.codigoExercicio2 = codigoExercicio2;
    }

    public int getNumeroDeSeries3() {
        return numeroDeSeries3;
    }

    public void setNumeroDeSeries3(int numeroDeSeries3) {
        this.numeroDeSeries3 = numeroDeSeries3;
    }

    public int getNumeroDeRepeticoes3() {
        return numeroDeRepeticoes3;
    }

    public void setNumeroDeRepeticoes3(int numeroDeRepeticoes3) {
        this.numeroDeRepeticoes3 = numeroDeRepeticoes3;
    }

    public int getCodigoExercicio3() {
        return codigoExercicio3;
    }

    public void setCodigoExercicio3(int codigoExercicio3) {
        this.codigoExercicio3 = codigoExercicio3;
    }

    public int getNumeroDeSeries4() {
        return numeroDeSeries4;
    }

    public void setNumeroDeSeries4(int numeroDeSeries4) {
        this.numeroDeSeries4 = numeroDeSeries4;
    }

    public int getNumeroDeRepeticoes4() {
        return numeroDeRepeticoes4;
    }

    public void setNumeroDeRepeticoes4(int numeroDeRepeticoes4) {
        this.numeroDeRepeticoes4 = numeroDeRepeticoes4;
    }

    public int getCodigoExercicio4() {
        return codigoExercicio4;
    }

    public void setCodigoExercicio4(int codigoExercicio4) {
        this.codigoExercicio4 = codigoExercicio4;
    }

    public int getNumeroDeSeries5() {
        return numeroDeSeries5;
    }

    public void setNumeroDeSeries5(int numeroDeSeries5) {
        this.numeroDeSeries5 = numeroDeSeries5;
    }

    public int getNumeroDeRepeticoes5() {
        return numeroDeRepeticoes5;
    }

    public void setNumeroDeRepeticoes5(int numeroDeRepeticoes5) {
        this.numeroDeRepeticoes5 = numeroDeRepeticoes5;
    }

    public int getCodigoExercicio5() {
        return codigoExercicio5;
    }

    public void setCodigoExercicio5(int codigoExercicio5) {
        this.codigoExercicio5 = codigoExercicio5;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + this.codigoAluno;
        hash = 59 * hash + this.codigoTreinador;
        hash = 59 * hash + Objects.hashCode(this.nomeTreino);
        hash = 59 * hash + this.numeroDeSeries;
        hash = 59 * hash + this.numeroDeRepeticoes;
        hash = 59 * hash + this.codigoExercicio;
        hash = 59 * hash + this.numeroDeSeries2;
        hash = 59 * hash + this.numeroDeRepeticoes2;
        hash = 59 * hash + this.codigoExercicio2;
        hash = 59 * hash + this.numeroDeSeries3;
        hash = 59 * hash + this.numeroDeRepeticoes3;
        hash = 59 * hash + this.codigoExercicio3;
        hash = 59 * hash + this.numeroDeSeries4;
        hash = 59 * hash + this.numeroDeRepeticoes4;
        hash = 59 * hash + this.codigoExercicio4;
        hash = 59 * hash + this.numeroDeSeries5;
        hash = 59 * hash + this.numeroDeRepeticoes5;
        hash = 59 * hash + this.codigoExercicio5;
        hash = 59 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Treino other = (Treino) obj;
        if (this.codigoAluno != other.codigoAluno) {
            return false;
        }
        if (this.codigoTreinador != other.codigoTreinador) {
            return false;
        }
        if (this.numeroDeSeries != other.numeroDeSeries) {
            return false;
        }
        if (this.numeroDeRepeticoes != other.numeroDeRepeticoes) {
            return false;
        }
        if (this.codigoExercicio != other.codigoExercicio) {
            return false;
        }
        if (this.numeroDeSeries2 != other.numeroDeSeries2) {
            return false;
        }
        if (this.numeroDeRepeticoes2 != other.numeroDeRepeticoes2) {
            return false;
        }
        if (this.codigoExercicio2 != other.codigoExercicio2) {
            return false;
        }
        if (this.numeroDeSeries3 != other.numeroDeSeries3) {
            return false;
        }
        if (this.numeroDeRepeticoes3 != other.numeroDeRepeticoes3) {
            return false;
        }
        if (this.codigoExercicio3 != other.codigoExercicio3) {
            return false;
        }
        if (this.numeroDeSeries4 != other.numeroDeSeries4) {
            return false;
        }
        if (this.numeroDeRepeticoes4 != other.numeroDeRepeticoes4) {
            return false;
        }
        if (this.codigoExercicio4 != other.codigoExercicio4) {
            return false;
        }
        if (this.numeroDeSeries5 != other.numeroDeSeries5) {
            return false;
        }
        if (this.numeroDeRepeticoes5 != other.numeroDeRepeticoes5) {
            return false;
        }
        if (this.codigoExercicio5 != other.codigoExercicio5) {
            return false;
        }
        if (this.codigo != other.codigo) {
            return false;
        }
        return Objects.equals(this.nomeTreino, other.nomeTreino);
    }

    @Override
    public String toString() {
        return "Treino{" + "codigoAluno=" + codigoAluno + ", codigoTreinador=" + codigoTreinador + ", nomeTreino=" + nomeTreino + ", numeroDeSeries=" + numeroDeSeries + ", numeroDeRepeticoes=" + numeroDeRepeticoes + ", codigoExercicio=" + codigoExercicio + ", numeroDeSeries2=" + numeroDeSeries2 + ", numeroDeRepeticoes2=" + numeroDeRepeticoes2 + ", codigoExercicio2=" + codigoExercicio2 + ", numeroDeSeries3=" + numeroDeSeries3 + ", numeroDeRepeticoes3=" + numeroDeRepeticoes3 + ", codigoExercicio3=" + codigoExercicio3 + ", numeroDeSeries4=" + numeroDeSeries4 + ", numeroDeRepeticoes4=" + numeroDeRepeticoes4 + ", codigoExercicio4=" + codigoExercicio4 + ", numeroDeSeries5=" + numeroDeSeries5 + ", numeroDeRepeticoes5=" + numeroDeRepeticoes5 + ", codigoExercicio5=" + codigoExercicio5 + ", codigo=" + codigo + '}';
    }
    
   
}
