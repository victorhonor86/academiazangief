
package modelo;

import java.util.Objects;


public class Aluno {
   
    private String nomeAluno;
    private String cpfAluno;
    private String telefoneAluno;
    private String emailAluno;
    private String enderecoAluno;
    private int codigo;

    public Aluno(String nomeAluno, int codigo) {
        this.nomeAluno = nomeAluno;
        this.codigo = codigo;
    }

    public Aluno(String nomeAluno, String cpfAluno, String telefoneAluno, String emailAluno, String enderecoAluno) {
        this.nomeAluno = nomeAluno;
        this.cpfAluno = cpfAluno;
        this.telefoneAluno = telefoneAluno;
        this.emailAluno = emailAluno;
        this.enderecoAluno = enderecoAluno;
    }

    public Aluno(String nomeAluno, String cpfAluno, String telefoneAluno, String emailAluno, String enderecoAluno, int codigo) {
        this.nomeAluno = nomeAluno;
        this.cpfAluno = cpfAluno;
        this.telefoneAluno = telefoneAluno;
        this.emailAluno = emailAluno;
        this.enderecoAluno = enderecoAluno;
        this.codigo = codigo;
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public String getCpfAluno() {
        return cpfAluno;
    }

    public void setCpfAluno(String cpfAluno) {
        this.cpfAluno = cpfAluno;
    }

    public String getTelefoneAluno() {
        return telefoneAluno;
    }

    public void setTelefoneAluno(String telefoneAluno) {
        this.telefoneAluno = telefoneAluno;
    }

    public String getEmailAluno() {
        return emailAluno;
    }

    public void setEmailAluno(String emailAluno) {
        this.emailAluno = emailAluno;
    }

    public String getEnderecoAluno() {
        return enderecoAluno;
    }

    public void setEnderecoAluno(String enderecoAluno) {
        this.enderecoAluno = enderecoAluno;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.nomeAluno);
        hash = 97 * hash + Objects.hashCode(this.cpfAluno);
        hash = 97 * hash + Objects.hashCode(this.telefoneAluno);
        hash = 97 * hash + Objects.hashCode(this.emailAluno);
        hash = 97 * hash + Objects.hashCode(this.enderecoAluno);
        hash = 97 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Aluno other = (Aluno) obj;
        return true;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nomeAluno=" + nomeAluno + ", cpfAluno=" + cpfAluno + ", telefoneAluno=" + telefoneAluno + ", emailAluno=" + emailAluno + ", enderecoAluno=" + enderecoAluno + ", codigo=" + codigo + '}';
    }

}
