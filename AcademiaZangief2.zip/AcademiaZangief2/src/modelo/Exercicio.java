
package modelo;

import java.util.Objects;


public class Exercicio {
   
    private String nomeExercicio;
    private String musculo;
    private String imagemReferencia;
    private int codigo;

    public Exercicio(String nomeExercicio, int codigo) {
        this.nomeExercicio = nomeExercicio;
        this.codigo = codigo;
    }

    public Exercicio(String nomeExercicio, String musculo, String imagemReferencia, int codigo) {
        this.nomeExercicio = nomeExercicio;
        this.musculo = musculo;
        this.imagemReferencia = imagemReferencia;
        this.codigo = codigo;
    }

    public Exercicio(String nomeExercicio, String musculo, String imagemReferencia) {
        this.nomeExercicio = nomeExercicio;
        this.musculo = musculo;
        this.imagemReferencia = imagemReferencia;
    }

    public Exercicio() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getNomeExercicio() {
        return nomeExercicio;
    }

    public void setNomeExercicio(String nomeExercicio) {
        this.nomeExercicio = nomeExercicio;
    }

    public String getMusculo() {
        return musculo;
    }

    public void setMusculo(String musculo) {
        this.musculo = musculo;
    }

    public String getImagemReferencia() {
        return imagemReferencia;
    }

    public void setImagemReferencia(String imagemReferencia) {
        this.imagemReferencia = imagemReferencia;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.nomeExercicio);
        hash = 71 * hash + Objects.hashCode(this.musculo);
        hash = 71 * hash + Objects.hashCode(this.imagemReferencia);
        hash = 71 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Exercicio other = (Exercicio) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.nomeExercicio, other.nomeExercicio)) {
            return false;
        }
        if (!Objects.equals(this.musculo, other.musculo)) {
            return false;
        }
        return Objects.equals(this.imagemReferencia, other.imagemReferencia);
    }

    @Override
    public String toString() {
        return "Exercicio{" + "nomeExercicio=" + nomeExercicio + ", musculo=" + musculo + ", imagemReferencia=" + imagemReferencia + ", codigo=" + codigo + '}';
    }

}
