
package modelo;

import java.util.Objects;


public class Avaliacao {
   
    
    private int codigoAluno;
    private int codigoTreinador;
    private String dataAvaliacao;
    private String altura;
    private String peso;
    private String bracoDireito;
    private String bracoEsquerdo;
    private String cintura;
    private String panturrilhaDireita;
    private String panturrilhaEsquerda;
    private int codigo;

    public Avaliacao(int codigoAluno, int codigoTreinador, String dataAvaliacao, String altura, String peso, String bracoDireito, String bracoEsquerdo, String cintura, String panturrilhaDireita, String panturrilhaEsquerda, int codigo) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.dataAvaliacao = dataAvaliacao;
        this.altura = altura;
        this.peso = peso;
        this.bracoDireito = bracoDireito;
        this.bracoEsquerdo = bracoEsquerdo;
        this.cintura = cintura;
        this.panturrilhaDireita = panturrilhaDireita;
        this.panturrilhaEsquerda = panturrilhaEsquerda;
        this.codigo = codigo;
    }

    public Avaliacao(int codigoAluno, int codigoTreinador, String dataAvaliacao, String altura, String peso, String bracoDireito, String bracoEsquerdo, String cintura, String panturrilhaDireita, String panturrilhaEsquerda) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.dataAvaliacao = dataAvaliacao;
        this.altura = altura;
        this.peso = peso;
        this.bracoDireito = bracoDireito;
        this.bracoEsquerdo = bracoEsquerdo;
        this.cintura = cintura;
        this.panturrilhaDireita = panturrilhaDireita;
        this.panturrilhaEsquerda = panturrilhaEsquerda;
    }

    public Avaliacao(int codigoAluno, int codigoTreinador, String dataAvaliacao, String altura, String peso, int codigo) {
        this.codigoAluno = codigoAluno;
        this.codigoTreinador = codigoTreinador;
        this.dataAvaliacao = dataAvaliacao;
        this.altura = altura;
        this.peso = peso;
        this.codigo = codigo;
    }

    public int getCodigoAluno() {
        return codigoAluno;
    }

    public void setCodigoAluno(int codigoAluno) {
        this.codigoAluno = codigoAluno;
    }

    public int getCodigoTreinador() {
        return codigoTreinador;
    }

    public void setCodigoTreinador(int codigoTreinador) {
        this.codigoTreinador = codigoTreinador;
    }

    public String getDataAvaliacao() {
        return dataAvaliacao;
    }

    public void setDataAvaliacao(String dataAvaliacao) {
        this.dataAvaliacao = dataAvaliacao;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getBracoDireito() {
        return bracoDireito;
    }

    public void setBracoDireito(String bracoDireito) {
        this.bracoDireito = bracoDireito;
    }

    public String getBracoEsquerdo() {
        return bracoEsquerdo;
    }

    public void setBracoEsquerdo(String bracoEsquerdo) {
        this.bracoEsquerdo = bracoEsquerdo;
    }

    public String getCintura() {
        return cintura;
    }

    public void setCintura(String cintura) {
        this.cintura = cintura;
    }

    public String getPanturrilhaDireita() {
        return panturrilhaDireita;
    }

    public void setPanturrilhaDireita(String panturrilhaDireita) {
        this.panturrilhaDireita = panturrilhaDireita;
    }

    public String getPanturrilhaEsquerda() {
        return panturrilhaEsquerda;
    }

    public void setPanturrilhaEsquerda(String panturrilhaEsquerda) {
        this.panturrilhaEsquerda = panturrilhaEsquerda;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + this.codigoAluno;
        hash = 79 * hash + this.codigoTreinador;
        hash = 79 * hash + Objects.hashCode(this.dataAvaliacao);
        hash = 79 * hash + Objects.hashCode(this.altura);
        hash = 79 * hash + Objects.hashCode(this.peso);
        hash = 79 * hash + Objects.hashCode(this.bracoDireito);
        hash = 79 * hash + Objects.hashCode(this.bracoEsquerdo);
        hash = 79 * hash + Objects.hashCode(this.cintura);
        hash = 79 * hash + Objects.hashCode(this.panturrilhaDireita);
        hash = 79 * hash + Objects.hashCode(this.panturrilhaEsquerda);
        hash = 79 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Avaliacao other = (Avaliacao) obj;
        if (this.codigoAluno != other.codigoAluno) {
            return false;
        }
        if (this.codigoTreinador != other.codigoTreinador) {
            return false;
        }
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.dataAvaliacao, other.dataAvaliacao)) {
            return false;
        }
        if (!Objects.equals(this.altura, other.altura)) {
            return false;
        }
        if (!Objects.equals(this.peso, other.peso)) {
            return false;
        }
        if (!Objects.equals(this.bracoDireito, other.bracoDireito)) {
            return false;
        }
        if (!Objects.equals(this.bracoEsquerdo, other.bracoEsquerdo)) {
            return false;
        }
        if (!Objects.equals(this.cintura, other.cintura)) {
            return false;
        }
        if (!Objects.equals(this.panturrilhaDireita, other.panturrilhaDireita)) {
            return false;
        }
        return Objects.equals(this.panturrilhaEsquerda, other.panturrilhaEsquerda);
    }

    @Override
    public String toString() {
        return "Avaliacao{" + "codigoAluno=" + codigoAluno + ", codigoTreinador=" + codigoTreinador + ", dataAvaliacao=" + dataAvaliacao + ", altura=" + altura + ", peso=" + peso + ", bracoDireito=" + bracoDireito + ", bracoEsquerdo=" + bracoEsquerdo + ", cintura=" + cintura + ", panturrilhaDireita=" + panturrilhaDireita + ", panturrilhaEsquerda=" + panturrilhaEsquerda + ", codigo=" + codigo + '}';
    }

    
   
    
}
