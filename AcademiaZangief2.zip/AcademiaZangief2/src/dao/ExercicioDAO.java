
package dao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jdbc.Conexao;
import modelo.Exercicio;
import java.util.ArrayList;
import java.util.List;

public class ExercicioDAO {
    
    public void adicionar(Exercicio exercicio)throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql= "INSERT INTO exercicio(nomeExercicio, musculo, imagemReferencia )VALUES (?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,exercicio.getNomeExercicio());
        ps.setString(2, exercicio.getMusculo());
        ps.setString(3,exercicio.getImagemReferencia());
        ps.execute();
        ps.close();
        conexao.close();
    }
    
    public List<Exercicio> buscarPelaNomeExercicio(String nomeExercicio) throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql = "Select * from exercicio where nomeExercicio like ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + nomeExercicio + "%");
        ResultSet rs = ps.executeQuery();
        List<Exercicio> exercicios = new ArrayList<>();
        while (rs.next()) {
            Exercicio exercicio = new Exercicio(rs.getString("nomeExercicio"),
                    rs.getString("musculo"), rs.getString("imagemReferencia"), 
                    rs.getInt("codigo"));
            exercicios.add(exercicio);
        }
        rs.close();
        ps.close();
        conexao.close();
        
        return exercicios;

    }


    public void remover(int codigo)throws SQLException{
         Connection conexao = new Conexao().getConexao();
         String sql="delete from exercicio where codigo= ?";
         PreparedStatement ps = conexao.prepareStatement(sql);
         ps.setInt(1, codigo);
         
         ps.executeUpdate();
         ps.close();
         conexao.close();
        
    }
    
    public void alterar(Exercicio exercicio)throws SQLException{
        
               
        Connection conexao = new Conexao().getConexao();
        String sql= "UPDATE exercicio set nomeExercicio=?, musculo=?, imagemReferencia=?"
                + " where codigo=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,exercicio.getNomeExercicio());
        ps.setString(2, exercicio.getMusculo());
        ps.setString(3,exercicio.getImagemReferencia());
        ps.setInt(4, exercicio.getCodigo());
        ps.executeUpdate();
        ps.close();
        conexao.close();
    }
    
    public List<Exercicio> buscar() {
        String sql = "select * from exercicio";
        Connection conexao = new Conexao().getConexao();

        try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            List<Exercicio> resultado = new ArrayList<>();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Exercicio exercicio = new Exercicio(
                rs.getString("nomeExercicio"),
                        rs.getString("musculo"),
                        rs.getString("imagemReferencia"),
                        rs.getInt("codigo")
                
                
                );
                exercicio.setCodigo(rs.getInt("codigo"));
                exercicio.setNomeExercicio(rs.getString("nomeExercicio"));
                resultado.add(exercicio);

            }
            return resultado;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;

    }    
}
