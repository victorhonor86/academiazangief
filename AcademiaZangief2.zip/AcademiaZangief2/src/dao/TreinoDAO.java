
package dao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jdbc.Conexao;
import modelo.Treino;
import java.util.ArrayList;
import java.util.List;

public class TreinoDAO {
    
    public void adicionar(Treino treino)throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql= "INSERT INTO treino(FKAluno, FKTreinador, nomeTreino, numeroDeSeries, numeroDeRepeticoes, FKExercicio, numeroDeSeries2, numeroDeRepeticoes2, FKExercicio2, numeroDeSeries3, numeroDeRepeticoes3, FKExercicio3, numeroDeSeries4, numeroDeRepeticoes4, FKExercicio4, numeroDeSeries5, numeroDeRepeticoes5, FKExercicio5)VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, treino.getCodigoAluno());
            ps.setInt(2, treino.getCodigoTreinador());
            ps.setString(3, treino.getNomeTreino());
            ps.setInt(4, treino.getNumeroDeSeries());
            ps.setInt(5, treino.getNumeroDeRepeticoes());
            ps.setInt(6, treino.getCodigoExercicio());
            ps.setInt(7, treino.getNumeroDeSeries2());
            ps.setInt(8, treino.getNumeroDeRepeticoes2());
            ps.setInt(9, treino.getCodigoExercicio2());
            ps.setInt(10, treino.getNumeroDeSeries3());
            ps.setInt(11, treino.getNumeroDeRepeticoes3());
            ps.setInt(12, treino.getCodigoExercicio3());
            ps.setInt(13, treino.getNumeroDeSeries4());
            ps.setInt(14, treino.getNumeroDeRepeticoes4());
            ps.setInt(15, treino.getCodigoExercicio4());
            ps.setInt(16, treino.getNumeroDeSeries5());
            ps.setInt(17, treino.getNumeroDeRepeticoes5());
            ps.setInt(18, treino.getCodigoExercicio5());
            
        ps.execute();
        ps.close();
        conexao.close();
    }
    
    public List<Treino> buscarPelaNomeTreino(String nomeTreino) throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql = "Select * from treino where nomeTreino like ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + nomeTreino + "%");
        ResultSet rs = ps.executeQuery();
        List<Treino> treinos = new ArrayList<>();
        while (rs.next()) {
            Treino treino = new Treino(
                    rs.getInt("FKAluno"),
                    rs.getInt("FKTreinador"),
                    rs.getString("nomeTreino"),
                    rs.getInt("codigo"));
            treinos.add(treino);
        }
        rs.close();
        ps.close();
        conexao.close();
        
        return treinos;

    }


    public void remover(int codigo)throws SQLException{
         Connection conexao = new Conexao().getConexao();
         String sql="delete from treino where codigo= ?";
         PreparedStatement ps = conexao.prepareStatement(sql);
         ps.setInt(1, codigo);
         
         ps.executeUpdate();
         ps.close();
         conexao.close();
        
    }
    
    public void alterar(Treino treino)throws SQLException{
        
               
        Connection conexao = new Conexao().getConexao();
        String sql= "UPDATE treino set FKAluno=?, FKTreinador=?, nomeTreino=?, NumeroDeSeries=?, NumeroDeRepeticoes=?, FKExercicio=?, NumeroDeSeries2=?, NumeroDeRepeticoes2=?, FKExercicio2=?, NumeroDeSeries3=?, NumeroDeRepeticoes3=?, FKExercicio3=?, NumeroDeSeries4=?, NumeroDeRepeticoes4=?, FKExercicio4=?, NumeroDeSeries5=?, NumeroDeRepeticoes5=?, FKExercicio5=?"
                + " where codigo=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1, treino.getCodigoAluno());
        ps.setInt(2, treino.getCodigoTreinador());
        ps.setString(3, treino.getNomeTreino());
        ps.setInt(4, treino.getNumeroDeSeries());
        ps.setInt(5, treino.getNumeroDeRepeticoes());
        ps.setInt(6, treino.getCodigoExercicio());
        ps.setInt(7, treino.getNumeroDeSeries2());
        ps.setInt(8, treino.getNumeroDeRepeticoes2());
        ps.setInt(9, treino.getCodigoExercicio2());
        ps.setInt(10, treino.getNumeroDeSeries3());
        ps.setInt(11, treino.getNumeroDeRepeticoes3());
        ps.setInt(12, treino.getCodigoExercicio3());
        ps.setInt(13, treino.getNumeroDeSeries4());
        ps.setInt(14, treino.getNumeroDeRepeticoes4());
        ps.setInt(15, treino.getCodigoExercicio4());
        ps.setInt(16, treino.getNumeroDeSeries5());
        ps.setInt(17, treino.getNumeroDeRepeticoes5());
        ps.setInt(18, treino.getCodigoExercicio5());
        ps.setInt(19, treino.getCodigo());
        ps.executeUpdate();
        ps.close();
        conexao.close();
    }
    
    
}
