
package dao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jdbc.Conexao;
import modelo.Aluno;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {
    
    public void adicionar(Aluno aluno)throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql= "INSERT INTO aluno(nomeAluno, cpfAluno, telefoneAluno, emailAluno, enderecoAluno )VALUES (?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,aluno.getNomeAluno());
        ps.setString(2, aluno.getCpfAluno());
        ps.setString(3,aluno.getTelefoneAluno());
        ps.setString(4,aluno.getEmailAluno());
        ps.setString(5,aluno.getEnderecoAluno());
        ps.execute();
        ps.close();
        conexao.close();
    }
    
    public List<Aluno> buscarPeloNomeAluno(String nomeAluno) throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql = "Select * from aluno where nomeAluno like ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + nomeAluno + "%");
        ResultSet rs = ps.executeQuery();
        List<Aluno> alunos = new ArrayList<>();
        while (rs.next()) {
            Aluno aluno = new Aluno(rs.getString("nomeAluno"),
                                    rs.getString("cpfAluno"),
                                    rs.getString("telefoneAluno"),
                                    rs.getString("emailAluno"),
                                    rs.getString("enderecoAluno"),
                                    rs.getInt("codigo"));
            alunos.add(aluno);
        }
        rs.close();
        ps.close();
        conexao.close();
        
        return alunos;

    }


    public void remover(int codigo)throws SQLException{
         Connection conexao = new Conexao().getConexao();
         String sql="delete from aluno where codigo= ?";
         PreparedStatement ps = conexao.prepareStatement(sql);
         ps.setInt(1, codigo);
         
         ps.executeUpdate();
         ps.close();
         conexao.close();
        
    }
    
    public void alterar(Aluno aluno)throws SQLException{
        
               
        Connection conexao = new Conexao().getConexao();
        String sql= "UPDATE aluno set nomeAluno=?, cpfAluno=?, telefoneAluno=?, emailAluno=?, enderecoAluno=?"
                + " where codigo=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,aluno.getNomeAluno());
        ps.setString(2, aluno.getCpfAluno());
        ps.setString(3,aluno.getTelefoneAluno());
        ps.setString(4,aluno.getEmailAluno());
        ps.setString(5,aluno.getEnderecoAluno());
        ps.setInt(6, aluno.getCodigo());
        ps.executeUpdate();
        ps.close();
        conexao.close();
    }
    
        public List<Aluno> buscar() {
        String sql = "select * from aluno";
        Connection conexao = new Conexao().getConexao();

        try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            List<Aluno> resultado = new ArrayList<>();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Aluno aluno = new Aluno(
                rs.getString("nomeAluno"),
                rs.getString("CpfAluno"),
                 rs.getString("telefoneAluno"),
                rs.getString("emailAluno"),
                rs.getString("enderecoAluno"),
                rs.getInt("codigo")
                );
                //aluno.setCodigo(rs.getInt("codigo"));
                
                
                resultado.add(aluno);

            }
            return resultado;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;

    }
    
    
    
    
    
    
}
