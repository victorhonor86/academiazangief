
package dao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jdbc.Conexao;
import modelo.Avaliacao;
import java.util.ArrayList;
import java.util.List;

public class AvaliacaoDAO {
    
    public void adicionar(Avaliacao avaliacao)throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql= "INSERT INTO avaliacao(FKAluno, FKTreinador, dataAvaliacao, altura, peso, bracoDireito, bracoEsquerdo, cintura, panturrilhaDireita, panturrilhaEsquerda )VALUES (?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1, avaliacao.getCodigoAluno());
        ps.setInt(2, avaliacao.getCodigoTreinador());
        ps.setString(3,avaliacao.getDataAvaliacao());
        ps.setString(4, avaliacao.getAltura());
        ps.setString(5,avaliacao.getPeso());
        ps.setString(6,avaliacao.getBracoDireito());
        ps.setString(7,avaliacao.getBracoEsquerdo());
        ps.setString(8,avaliacao.getCintura());
        ps.setString(9,avaliacao.getPanturrilhaDireita());
        ps.setString(10,avaliacao.getPanturrilhaEsquerda());
        ps.execute();
        ps.close();
        conexao.close();
    }
    
    public List<Avaliacao> buscarPeloNomeAvaliacao(String dataAvaliacao) throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql = "Select * from avaliacao where dataAvaliacao like ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + dataAvaliacao + "%");
        ResultSet rs = ps.executeQuery();
        List<Avaliacao> avaliacaos = new ArrayList<>();
        while (rs.next()) {
            Avaliacao avaliacao = new Avaliacao(
                                   rs.getInt("FKAluno"),
                                   rs.getInt("FKTreinador"),
                            rs.getString("dataAvaliacao"),
                                    rs.getString("altura"),
                                    rs.getString("peso"),
                                    rs.getInt("codigo"));
            avaliacaos.add(avaliacao);
        }
        rs.close();
        ps.close();
        conexao.close();
        
        return avaliacaos;

    }


    public void remover(int codigo)throws SQLException{
         Connection conexao = new Conexao().getConexao();
         String sql="delete from avaliacao where codigo= ?";
         PreparedStatement ps = conexao.prepareStatement(sql);
         ps.setInt(1, codigo);
         
         ps.executeUpdate();
         ps.close();
         conexao.close();
        
    }
    
    public void alterar(Avaliacao avaliacao)throws SQLException{
        
               
        Connection conexao = new Conexao().getConexao();
        String sql= "UPDATE avaliacao set FKAluno=?, FKTreinador=?, dataAvaliacao=?, altura=?, peso=?, bracoDireito=?, bracoEsquerdo=?, cintura=?, panturrilhaDireita=?, panturrilhaEsquerda=?"
                + " where codigo=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1,avaliacao.getCodigoAluno());
        ps.setInt(2, avaliacao.getCodigoTreinador());
        ps.setString(3,avaliacao.getDataAvaliacao());
        ps.setString(4,avaliacao.getAltura());
        ps.setString(5,avaliacao.getPeso());
        ps.setString(6,avaliacao.getBracoDireito());
        ps.setString(7,avaliacao.getBracoEsquerdo());
        ps.setString(8,avaliacao.getCintura());
        ps.setString(9,avaliacao.getPanturrilhaDireita());
        ps.setString(10,avaliacao.getPanturrilhaEsquerda());
        ps.setInt(11, avaliacao.getCodigo());
        ps.executeUpdate();
        ps.close();
        conexao.close();
    }
    
  

    }
  