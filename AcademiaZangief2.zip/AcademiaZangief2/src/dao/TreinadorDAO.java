
package dao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jdbc.Conexao;
import modelo.Treinador;
import java.util.ArrayList;
import java.util.List;

public class TreinadorDAO {
    
    public void adicionar(Treinador treinador)throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql= "INSERT INTO treinador(nomeTreinador, cpfTreinador, telefoneTreinador, emailTreinador, enderecoTreinador )VALUES (?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,treinador.getNomeTreinador());
        ps.setString(2, treinador.getCpfTreinador());
        ps.setString(3,treinador.getTelefoneTreinador());
        ps.setString(4,treinador.getEmailTreinador());
        ps.setString(5,treinador.getEnderecoTreinador());
        ps.execute();
        ps.close();
        conexao.close();
    }
    
    public List<Treinador> buscarPeloNomeTreinador(String nomeTreinador) throws SQLException{
        Connection conexao = new Conexao().getConexao();
        String sql = "Select * from treinador where nomeTreinador like ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, "%" + nomeTreinador + "%");
        ResultSet rs = ps.executeQuery();
        List<Treinador> treinadors = new ArrayList<>();
        while (rs.next()) {
            Treinador treinador = new Treinador(rs.getString("nomeTreinador"),
                                    rs.getString("cpfTreinador"),
                                    rs.getString("telefoneTreinador"),
                                    rs.getString("emailTreinador"),
                                    rs.getString("enderecoTreinador"),
                                    rs.getInt("codigo"));
            treinadors.add(treinador);
        }
        rs.close();
        ps.close();
        conexao.close();
        
        return treinadors;

    }


    public void remover(int codigo)throws SQLException{
         Connection conexao = new Conexao().getConexao();
         String sql="delete from treinador where codigo= ?";
         PreparedStatement ps = conexao.prepareStatement(sql);
         ps.setInt(1, codigo);
         
         ps.executeUpdate();
         ps.close();
         conexao.close();
        
    }
    
    public void alterar(Treinador treinador)throws SQLException{
        
               
        Connection conexao = new Conexao().getConexao();
        String sql= "UPDATE treinador set nomeTreinador=?, cpfTreinador=?, telefoneTreinador=?, emailTreinador=?, enderecoTreinador=?"
                + " where codigo=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1,treinador.getNomeTreinador());
        ps.setString(2, treinador.getCpfTreinador());
        ps.setString(3,treinador.getTelefoneTreinador());
        ps.setString(4,treinador.getEmailTreinador());
        ps.setString(5,treinador.getEnderecoTreinador());
        ps.setInt(6, treinador.getCodigo());
        ps.executeUpdate();
        ps.close();
        conexao.close();
    }
    
        public List<Treinador> buscar() {
        String sql = "select * from treinador";
        Connection conexao = new Conexao().getConexao();

        try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            List<Treinador> resultado = new ArrayList<>();
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Treinador treinador = new Treinador(
                rs.getString("nomeTreinador"),
                rs.getString("CpfTreinador"),
                rs.getString("telefoneTreinador"),
                rs.getString("emailTreinador"),
                rs.getString("enderecoTreinador"),
                rs.getInt("codigo")
                
                
                
                );

                resultado.add(treinador);

            }
            return resultado;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;

    }
}
