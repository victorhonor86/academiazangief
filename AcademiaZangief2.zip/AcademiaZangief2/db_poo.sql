-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05/07/2023 às 03:46
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_poo`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `codigo` int(11) NOT NULL,
  `nomeAluno` varchar(32) NOT NULL,
  `cpfAluno` varchar(32) NOT NULL,
  `telefoneAluno` varchar(32) NOT NULL,
  `emailAluno` varchar(32) NOT NULL,
  `enderecoAluno` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`codigo`, `nomeAluno`, `cpfAluno`, `telefoneAluno`, `emailAluno`, `enderecoAluno`) VALUES
(4, 'Frango UM', '123', '456', '789', '1000'),
(5, 'Frango DOIS', '213123', '1231', '12312', '1231'),
(6, 'Maromba UM', '131', '123', '1321', '123'),
(7, 'Maromba DOIS', '4141', '1141', '4125', '1231');

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacao`
--

CREATE TABLE `avaliacao` (
  `codigo` int(11) NOT NULL,
  `FKAluno` int(11) NOT NULL,
  `FKTreinador` int(11) NOT NULL,
  `dataAvaliacao` varchar(32) NOT NULL,
  `altura` varchar(11) NOT NULL,
  `peso` varchar(11) NOT NULL,
  `bracoDireito` varchar(11) NOT NULL,
  `bracoEsquerdo` varchar(11) NOT NULL,
  `cintura` varchar(11) NOT NULL,
  `panturrilhaDireita` varchar(11) NOT NULL,
  `panturrilhaEsquerda` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `avaliacao`
--

INSERT INTO `avaliacao` (`codigo`, `FKAluno`, `FKTreinador`, `dataAvaliacao`, `altura`, `peso`, `bracoDireito`, `bracoEsquerdo`, `cintura`, `panturrilhaDireita`, `panturrilhaEsquerda`) VALUES
(4, 5, 9, '10/05', '165', '60', '50', '50', '100', '50', '50'),
(5, 4, 2, '25/04', '180', '85', '50', '50', '100', '50', '50'),
(6, 6, 3, '10/03', '200', '120', '50', '50', '100', '50', '50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `exercicio`
--

CREATE TABLE `exercicio` (
  `codigo` int(11) NOT NULL,
  `nomeExercicio` varchar(32) NOT NULL,
  `musculo` varchar(32) NOT NULL,
  `imagemReferencia` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `exercicio`
--

INSERT INTO `exercicio` (`codigo`, `nomeExercicio`, `musculo`, `imagemReferencia`) VALUES
(1, 'SUPINO', 'PEITO', '412'),
(2, 'Supino com halter', 'Peito', '126'),
(4, 'Biceps Scott', 'Biceps', '123'),
(5, 'Biceps com Halter', 'Biceps', '1111'),
(6, 'Agachamento', 'Gluteos', '1212'),
(7, 'Afundo', 'Gluteos', '444');

-- --------------------------------------------------------

--
-- Estrutura para tabela `treinador`
--

CREATE TABLE `treinador` (
  `codigo` int(11) NOT NULL,
  `nomeTreinador` varchar(20) NOT NULL,
  `cpfTreinador` varchar(20) NOT NULL,
  `telefoneTreinador` varchar(20) NOT NULL,
  `emailTreinador` varchar(20) NOT NULL,
  `enderecoTreinador` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `treinador`
--

INSERT INTO `treinador` (`codigo`, `nomeTreinador`, `cpfTreinador`, `telefoneTreinador`, `emailTreinador`, `enderecoTreinador`) VALUES
(2, 'Ed Lemond', '123', '5555', 'emailbomba@gmail.com', 'Madagascar'),
(3, 'Ryu', '12345', '131231', 'hadouken@bol.com', 'Japao'),
(4, 'Zangief', '131231', '12312312', 'Lariat@bol.com', 'URSS'),
(5, 'Chun-Li', '13123', '123123', 'Spiningbirdkick', 'China'),
(6, 'Ken', '192380192', '131231', 'Shoryuken@bol', 'USA'),
(7, 'Leo Stronda', '123', '5555', 'emailbomba@gmail.com', 'BR'),
(8, 'Paulo Muzy', '171', '12312', 'amoroberta@bol.com', 'SP'),
(9, 'Arnold Schwarz', '3131', '31231', 'Schwazernegger@bol', 'Austria');

-- --------------------------------------------------------

--
-- Estrutura para tabela `treino`
--

CREATE TABLE `treino` (
  `codigo` int(11) NOT NULL,
  `FKAluno` int(11) NOT NULL,
  `FKTreinador` int(11) NOT NULL,
  `FKExercicio` int(11) NOT NULL,
  `numeroDeSeries` int(11) NOT NULL,
  `numeroDeRepeticoes` int(11) NOT NULL,
  `numeroDeSeries2` int(11) NOT NULL,
  `numeroDeRepeticoes2` int(11) NOT NULL,
  `FKExercicio2` int(11) NOT NULL,
  `numeroDeSeries3` int(11) NOT NULL,
  `numeroDeRepeticoes3` int(11) NOT NULL,
  `FKExercicio3` int(11) NOT NULL,
  `numeroDeSeries4` int(11) NOT NULL,
  `numeroDeRepeticoes4` int(11) NOT NULL,
  `FKExercicio4` int(11) NOT NULL,
  `numeroDeSeries5` int(11) NOT NULL,
  `numeroDeRepeticoes5` int(11) NOT NULL,
  `FKExercicio5` int(11) NOT NULL,
  `nomeTreino` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `treino`
--

INSERT INTO `treino` (`codigo`, `FKAluno`, `FKTreinador`, `FKExercicio`, `numeroDeSeries`, `numeroDeRepeticoes`, `numeroDeSeries2`, `numeroDeRepeticoes2`, `FKExercicio2`, `numeroDeSeries3`, `numeroDeRepeticoes3`, `FKExercicio3`, `numeroDeSeries4`, `numeroDeRepeticoes4`, `FKExercicio4`, `numeroDeSeries5`, `numeroDeRepeticoes5`, `FKExercicio5`, `nomeTreino`) VALUES
(18, 4, 9, 1, 1, 6, 1, 6, 1, 1, 6, 1, 1, 6, 1, 1, 6, 1, 'B'),
(19, 5, 3, 1, 2, 6, 4, 8, 2, 6, 12, 4, 2, 15, 5, 4, 15, 6, 'Hadouken'),
(20, 6, 4, 1, 1, 6, 1, 8, 2, 1, 12, 4, 1, 15, 5, 1, 15, 6, 'Lariat'),
(21, 7, 7, 6, 2, 6, 6, 8, 4, 5, 12, 2, 2, 15, 2, 4, 15, 7, 'Birlll'),
(22, 5, 7, 1, 2, 10, 4, 12, 2, 6, 20, 4, 2, 10, 5, 4, 10, 2, 'ABC');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`codigo`);

--
-- Índices de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `FKAluno1` (`FKAluno`),
  ADD KEY `FKTreinador1` (`FKTreinador`);

--
-- Índices de tabela `exercicio`
--
ALTER TABLE `exercicio`
  ADD PRIMARY KEY (`codigo`);

--
-- Índices de tabela `treinador`
--
ALTER TABLE `treinador`
  ADD PRIMARY KEY (`codigo`);

--
-- Índices de tabela `treino`
--
ALTER TABLE `treino`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `FKnomeAluno` (`FKAluno`),
  ADD KEY `FKnomeTreinador` (`FKTreinador`),
  ADD KEY `FKnomeExercicio` (`FKExercicio`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `exercicio`
--
ALTER TABLE `exercicio`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `treinador`
--
ALTER TABLE `treinador`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `treino`
--
ALTER TABLE `treino`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD CONSTRAINT `FKAluno1` FOREIGN KEY (`FKAluno`) REFERENCES `aluno` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FKTreinador1` FOREIGN KEY (`FKTreinador`) REFERENCES `treinador` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `treino`
--
ALTER TABLE `treino`
  ADD CONSTRAINT `FKnomeAluno` FOREIGN KEY (`FKAluno`) REFERENCES `aluno` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FKnomeExercicio` FOREIGN KEY (`FKExercicio`) REFERENCES `exercicio` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FKnomeTreinador` FOREIGN KEY (`FKTreinador`) REFERENCES `treinador` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
